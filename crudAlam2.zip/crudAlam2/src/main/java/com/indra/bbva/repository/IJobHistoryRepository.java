package com.indra.bbva.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.indra.bbva.entity.JobHistoryEntity;
import com.indra.bbva.entity.JobHistoryEntityId;

@Repository
public interface IJobHistoryRepository extends JpaRepository<JobHistoryEntity, JobHistoryEntityId>{

	List<JobHistoryEntity> findByEmployeeId(int employeeId);
	List<JobHistoryEntity> findByStartDate(Date startDate);
}