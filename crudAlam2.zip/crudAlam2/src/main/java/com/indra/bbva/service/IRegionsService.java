package com.indra.bbva.service;

import java.util.List;

import com.indra.bbva.entity.RegionsEntity;

public interface IRegionsService {
	
	public abstract List<RegionsEntity> findAll();
	
	public abstract RegionsEntity findById(int theId);
	
	public abstract void save(RegionsEntity theRegion);
	
	public abstract void updateById(RegionsEntity theRegion);
	
	public abstract void deleteById(int theId);

}
