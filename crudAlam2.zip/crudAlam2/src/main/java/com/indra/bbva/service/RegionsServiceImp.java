package com.indra.bbva.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.bbva.entity.RegionsEntity;
import com.indra.bbva.repository.IRegionsRepository;

@Service
public class RegionsServiceImp implements IRegionsService {

	// inject IRegionsRepository
	private IRegionsRepository regionsRepository;
	
	@Autowired
	public RegionsServiceImp(IRegionsRepository theRegionRepository) {
		regionsRepository = theRegionRepository;
	}
	
	@Override
	public List<RegionsEntity> findAll() {
		return regionsRepository.findAll();
	}

	@Override
	public RegionsEntity findById(int theId) {
		Optional<RegionsEntity> tempRegion = regionsRepository.findById(theId);
		RegionsEntity theRegion = null;
		if (tempRegion.isPresent())
			theRegion = tempRegion.get();
		else
			//we didn't find the region
			throw new RuntimeException("Did not find region id - " + theId);
		return theRegion;
	}

	@Override
	public void save(RegionsEntity theRegion) {
		int theId = theRegion.getRegionId();
		Optional<RegionsEntity> tempRegion = regionsRepository.findById(theId);
		if (tempRegion.isPresent())
			// already exists region id
			throw new RuntimeException("Already exists region id - " + theId);
		else
			regionsRepository.save(theRegion);
	}
	
	@Override
	public void updateById(RegionsEntity theRegion) {
		int theId = theRegion.getRegionId();
		Optional<RegionsEntity> tempRegion = regionsRepository.findById(theId);
		if (tempRegion.isPresent())
			regionsRepository.save(theRegion);
		else
			// we didn't find the region
			throw new RuntimeException("Did not find region id - " + theId);
	}
	
	@Override
	public void deleteById(int theId) {
		Optional<RegionsEntity> tempRegion = regionsRepository.findById(theId);
		if (tempRegion.isPresent())
			regionsRepository.deleteById(theId);
		else
			// we didn't find the region
			throw new RuntimeException("Did not find region id - " + theId);
	}

}
