package com.indra.bbva.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.indra.bbva.entity.DepartmentsEntity;
import com.indra.bbva.service.IDepartmentsService;

@RestController
@RequestMapping("/hr")
public class DepartmentsRestController {

	// inject IDepartmentsService
	private IDepartmentsService departmentsService;
	
	@Autowired
	public DepartmentsRestController(IDepartmentsService theDepartmentsService) {
		departmentsService = theDepartmentsService;
	}
	
	// expose "/departments" and return list of departments
	@GetMapping("/departments")
	public List<DepartmentsEntity> getDepartments() {
		return departmentsService.findAll();
	}
	
	// add mapping for GET /departments/{departmentId}
	@GetMapping("/departments/{departmentId}")
	public DepartmentsEntity getDepartment(@PathVariable int departmentId) {
		return departmentsService.findById(departmentId);

	}
	
	// add mapping for POST /department - add new employee
	@PostMapping("/departments")
	public DepartmentsEntity addDepartment(@RequestBody DepartmentsEntity theDepartment) {
		departmentsService.save(theDepartment);
		return theDepartment;
	}
	
	// add mapping for PUT /locations - update existing location
	@PutMapping("/departments")
	public DepartmentsEntity updateDepartment(@RequestBody DepartmentsEntity theDepartment) {
		departmentsService.updateById(theDepartment);
		return theDepartment;
	}
	
	@DeleteMapping("/departments/{departmentId}")
	public String deleteDepartment(@PathVariable int departmentId) {
		departmentsService.deleteById(departmentId);
		return "Deleted department id - " + departmentId;
	}
	
}
