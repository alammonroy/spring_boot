package com.indra.bbva.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.sun.istack.NotNull;

@Entity
@Table(name="LOCATIONS")
public class LocationsEntity {

	// define fields
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="LOCATIONS_SEQ")
	@SequenceGenerator(name="LOCATIONS_SEQ", sequenceName="LOCATIONS_SEQ", allocationSize=1)
	@NotNull
	@Column(name="LOCATION_ID")
	private Integer locationId;
	
	@NotNull
	@Column(name="CITY")
	private String city;
	
	@Column(name="STATE_PROVINCE")
	private String stateProvince;

	@Column(name="COUNTRY_ID")
	private String countryId;
	
	@Column(name="STREET_ADDRESS")
	private String StreetAddress;
	
	@Column(name="POSTAL_CODE")
	private String postalCode;
	
	
	// define constructor
	
	public LocationsEntity() {}


	public LocationsEntity(Integer locationId, String city, String stateProvince, String countryId,
			String streetAddress, String postalCode) {
		super();
		this.locationId = locationId;
		this.city = city;
		this.stateProvince = stateProvince;
		this.countryId = countryId;
		StreetAddress = streetAddress;
		this.postalCode = postalCode;
	}


	// define getters and setters
	
	public Integer getLocationId() {
		return locationId;
	}


	public void setLocationId(Integer locationId) {
		this.locationId = locationId;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getStateProvince() {
		return stateProvince;
	}


	public void setStateProvince(String stateProvince) {
		this.stateProvince = stateProvince;
	}


	public String getCountryId() {
		return countryId;
	}


	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}


	public String getStreetAddress() {
		return StreetAddress;
	}


	public void setStreetAddress(String streetAddress) {
		StreetAddress = streetAddress;
	}


	public String getPostalCode() {
		return postalCode;
	}


	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	
	// define toString

	@Override
	public String toString() {
		return "LocationsEntity [locationId=" + locationId + ", city=" + city + ", stateProvince=" + stateProvince
				+ ", countryId=" + countryId + ", StreetAddress=" + StreetAddress + ", postalCode=" + postalCode + "]";
	}
	
	
}
