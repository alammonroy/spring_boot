package com.indra.bbva.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.indra.bbva.entity.JobHistoryEntity;
import com.indra.bbva.service.IJobHistoryService;

@RestController
@RequestMapping("/hr")
public class JobHistoryRestController {

	// inject IJobHistoryService
	private IJobHistoryService jobHistoryService;
	
	@Autowired
	public JobHistoryRestController(IJobHistoryService theJobHistoryService) {
		jobHistoryService = theJobHistoryService;
	}
	
	@GetMapping("/jobHistory")
	public List<JobHistoryEntity> getJobsHistory() {
		return jobHistoryService.findAll();
	}

	@GetMapping("/jobHistory/{employeeId}/{startId}")
	public JobHistoryEntity getJobHistory(@PathVariable int employeeId, @PathVariable String startId) throws ParseException {
		DateFormat fecha = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		Date startIdDate = fecha.parse(startId);
		return jobHistoryService.findById(employeeId, startIdDate);
	}
	
	@PostMapping("/jobHistory")
	public JobHistoryEntity addJobHistory(@RequestBody JobHistoryEntity theJobHistory) {
		jobHistoryService.save(theJobHistory);
		return theJobHistory;
	}
	
	@PutMapping("/jobHistory")
	public JobHistoryEntity updateJobHistory(@RequestBody JobHistoryEntity theJobHistory) {
		jobHistoryService.updateById(theJobHistory);
		return theJobHistory;
	}
	
	@DeleteMapping("/jobHistory/{employeeId}/{startId}")
	public String deleteJobHistory(@PathVariable int employeeId, @PathVariable String startId) throws ParseException {
		DateFormat fecha = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		Date startIdDate = fecha.parse(startId);
		jobHistoryService.deleteById(employeeId, startIdDate);
		return "Deleted JobHistory id - " + employeeId + " / " + startId;
	}
	
	@GetMapping("/jobHistory/{employeeId}/all")
	public List<JobHistoryEntity> getJobHistoryByEmployeeId(@PathVariable int employeeId) {
		return jobHistoryService.findByEmployeeId(employeeId);
	}
	
	@GetMapping("/jobHistory/all/{startId}")
	public List<JobHistoryEntity> getJobHistoryByStartDate( @PathVariable String startId) throws ParseException {
		DateFormat fecha = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		Date startIdDate = fecha.parse(startId);
		return jobHistoryService.findByStartDate(startIdDate);
	}
}
