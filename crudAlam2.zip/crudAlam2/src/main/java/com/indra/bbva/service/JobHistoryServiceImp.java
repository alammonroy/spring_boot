package com.indra.bbva.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.bbva.entity.JobHistoryEntity;
import com.indra.bbva.entity.JobHistoryEntityId;
import com.indra.bbva.repository.IJobHistoryRepository;

@Service
public class JobHistoryServiceImp implements IJobHistoryService {

	// inject IJobHistoryRepository
	private IJobHistoryRepository jobHistoryRepository;
	
	@Autowired
	public JobHistoryServiceImp(IJobHistoryRepository theJobHistoryRepository) {
		jobHistoryRepository = theJobHistoryRepository;
	}
	
	@Override
	public List<JobHistoryEntity> findAll() {
		return jobHistoryRepository.findAll();
	}

	@Override
	public JobHistoryEntity findById(int employeeId, Date startId) {
		JobHistoryEntityId completeId = new JobHistoryEntityId(employeeId, startId);
		Optional<JobHistoryEntity> tempJobHistory = jobHistoryRepository.findById(completeId);
		JobHistoryEntity theHobHistory = null;
		if (tempJobHistory.isPresent())
			theHobHistory = tempJobHistory.get();
		else
			// we didn't find the jobHistory
			throw new RuntimeException("Did not find jobHistory id - " + employeeId + " / " + startId);
		return theHobHistory;
	}
	
	@Override
	public void save(JobHistoryEntity theJobHistory) {
		int employeeId = theJobHistory.getEmployeeId();
		Date startId = theJobHistory.getStartDate();
		Optional<JobHistoryEntity> tempJobHistory = jobHistoryRepository.findById(new JobHistoryEntityId(employeeId, startId));
		if (tempJobHistory.isPresent())
			// already exists jobHistory id
			throw new RuntimeException("Already exists jobhistory id - " + employeeId + " / " + startId);
		else
			jobHistoryRepository.save(theJobHistory);
	}
	
	@Override
	public void updateById(JobHistoryEntity theJobHistory) {
		int employeeId = theJobHistory.getEmployeeId();
		Date startId = theJobHistory.getStartDate();
		Optional<JobHistoryEntity> tempJobHistory = jobHistoryRepository.findById(new JobHistoryEntityId(employeeId, startId));
		if (tempJobHistory.isPresent())
			jobHistoryRepository.save(theJobHistory);
		else
			// we didn't find the jobHistory
			throw new RuntimeException("Did not find jobHistory id - " + employeeId + " / " + startId);
	}
	
	@Override
	public void deleteById(int employeeId, Date startId) {
		JobHistoryEntityId completeId = new JobHistoryEntityId(employeeId, startId);
		Optional<JobHistoryEntity> tempJobHistory = jobHistoryRepository.findById(completeId);
		if (tempJobHistory.isPresent())
			jobHistoryRepository.deleteById(completeId);
		else
			// we didn't find the jobHistory
			throw new RuntimeException("Did not find jobHistory id - " + employeeId + " / " + startId);
	}
	
	
	@Override
	public List<JobHistoryEntity> findByEmployeeId(int employeeId) {
		return jobHistoryRepository.findByEmployeeId(employeeId);
	}
	
	@Override
	public List<JobHistoryEntity> findByStartDate(Date startId) {
		return jobHistoryRepository.findByStartDate(startId);
	}
	
}
