package com.indra.bbva.service;

import java.util.List;

import com.indra.bbva.entity.EmployeesEntity;

public interface IEmployeesService {

	public abstract List<EmployeesEntity> findAll();
	
	public abstract EmployeesEntity findById(int theId);
	
	public abstract void save(EmployeesEntity theEmployee);
	
	public abstract void updateById(EmployeesEntity theEmployee);
	
	public abstract void deleteById(int theId);
	
}
