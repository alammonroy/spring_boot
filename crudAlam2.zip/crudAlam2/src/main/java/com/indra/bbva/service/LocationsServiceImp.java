package com.indra.bbva.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.bbva.entity.LocationsEntity;
import com.indra.bbva.repository.ILocationsRepository;

@Service
public class LocationsServiceImp implements ILocationsService {

	// inject ILocationsRepository
	private ILocationsRepository locationsRepository;
	
	@Autowired
	public LocationsServiceImp(ILocationsRepository theLocationRepository) {
		locationsRepository = theLocationRepository;
	}
	
	@Override
	public List<LocationsEntity> findAll() {
		return locationsRepository.findAll();
	}

	@Override
	public LocationsEntity findById(int theId) {
		Optional<LocationsEntity> tempLocation = locationsRepository.findById(theId);
		LocationsEntity theLocation = null;
		if (tempLocation.isPresent())
			theLocation = tempLocation.get();
		else
			// we didn't find the location
			throw new RuntimeException("Did not find location id - " + theId);
		return theLocation;
	}

	@Override
	public void save(LocationsEntity theLocation) {
		locationsRepository.save(theLocation);
	}

	@Override
	public void updateById(LocationsEntity theLocation) {
		int theId = theLocation.getLocationId();
		Optional<LocationsEntity> tempLocation = locationsRepository.findById(theId);
		if (tempLocation.isPresent())
			locationsRepository.save(theLocation);
		else
			// we didn't find the location
			throw new RuntimeException("Did not find location id - " + theId);
	}
	
	@Override
	public void deleteById(int theId) {
		Optional<LocationsEntity> tempLocation = locationsRepository.findById(theId);
		if (tempLocation.isPresent())
			locationsRepository.deleteById(theId);
		else
			// we didn't find the location
			throw new RuntimeException("Did not find location id - " + theId);
	}
}
