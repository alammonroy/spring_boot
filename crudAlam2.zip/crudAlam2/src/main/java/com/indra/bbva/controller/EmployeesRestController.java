package com.indra.bbva.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.indra.bbva.entity.EmployeesEntity;
import com.indra.bbva.service.IEmployeesService;

@RestController
@RequestMapping("/hr")
public class EmployeesRestController {

	// inject IEmployeesService
	private IEmployeesService employeesService;
	
	@Autowired
	public EmployeesRestController(IEmployeesService theEmployeesService) {
		employeesService = theEmployeesService;
	}
	
	// expose "/employees" and return list of employees
	@GetMapping("/employees")
	public List<EmployeesEntity> getEmployees() {
		return employeesService.findAll();
	}
	
	// add mapping for GET /employees/{employeeId}
	@GetMapping("/employees/{employeeId}")
	public EmployeesEntity getEmployee(@PathVariable int employeeId) {
		return employeesService.findById(employeeId);

	}
	
	// add mapping for POST /employees - add new employee
	@PostMapping("/employees")
	public EmployeesEntity addEmployee(@RequestBody EmployeesEntity theEmployee) {
		employeesService.save(theEmployee);
		return theEmployee;
	}
	
	// add mapping for PUT /employees - update existing employee
	@PutMapping("/employees")
	public EmployeesEntity updateEmployee(@RequestBody EmployeesEntity theEmployee) {
		employeesService.updateById(theEmployee);
		return theEmployee;
	}
	
	@DeleteMapping("/employees/{employeeId}")
	public String deleteEmployee(@PathVariable int employeeId) {
		employeesService.deleteById(employeeId);
		return "Deleted employee id - " + employeeId;
	}
}
