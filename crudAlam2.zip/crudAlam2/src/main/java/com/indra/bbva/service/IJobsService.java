package com.indra.bbva.service;

import java.util.List;

import com.indra.bbva.entity.JobsEntity;

public interface IJobsService {

	public abstract List<JobsEntity> findAll();
	
	public abstract JobsEntity findById(String theId);
	
	public abstract void save(JobsEntity theJob);
	
	public abstract void updateById(JobsEntity theJob);
	
	public abstract void deleteById(String theId);
	
}
