package com.indra.bbva.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.sun.istack.NotNull;

@Entity
@Table(name="JOB_HISTORY")
@IdClass(JobHistoryEntityId.class)
public class JobHistoryEntity {

	// define fields
	
	@Id
	@NotNull
	@Column(name="EMPLOYEE_ID")
	private Integer employeeId;
	
	@Id
	@NotNull
	@Column(name="START_DATE")
//	@Temporal(TemporalType.DATE)
//	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date startDate;
	
	@NotNull
	@Column(name="END_DATE")
//	@Temporal(TemporalType.DATE)
//	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date endDate;
	
	@NotNull
	@Column(name="JOB_ID")
	private String jobId;

	@Column(name="DEPARTMENT_ID")
	private Integer departmentId;
	
	
	// define constructor
	
	public JobHistoryEntity() {}

	public JobHistoryEntity(Integer employeeId, Date startDate, Date endDate, String jobId, Integer departmentId) {
		super();
		this.employeeId = employeeId;
		this.startDate = startDate;
		this.endDate = endDate;
		this.jobId = jobId;
		this.departmentId = departmentId;
	}


	// define setters and getters
	
	public Integer getEmployeeId() {
		return employeeId;
	}


	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}


	public Date getStartDate() {
		return startDate;
	}


	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}


	public Date getEndDate() {
		return endDate;
	}


	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}


	public String getJobId() {
		return jobId;
	}


	public void setJobId(String jobId) {
		this.jobId = jobId;
	}


	public Integer getDepartmentId() {
		return departmentId;
	}


	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}


	// define toString
	
	@Override
	public String toString() {
		return "JobHistoryEntity [employeeId=" + employeeId + ", startDate=" + startDate + ", endDate=" + endDate
				+ ", jobId=" + jobId + ", departmentId=" + departmentId + "]";
	}

}
