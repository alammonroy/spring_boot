package com.indra.bbva.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.sun.istack.NotNull;

@Entity
@Table(name="EMPLOYEES")
public class EmployeesEntity {
	
	// define fields
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="EMPLOYEES_SEQ")
	@SequenceGenerator(name="EMPLOYEES_SEQ", sequenceName="EMPLOYEES_SEQ", allocationSize=1)
	@NotNull
	@Column(name="EMPLOYEE_ID")
	private Integer employeeId;
	
	@NotNull
	@Column(name="HIRE_DATE")
	private Date hireDate;
	
	@NotNull
	@Column(name="JOB_ID")
	private String jobId;
	
	@NotNull
	@Column(name="EMAIL")
	private String email;
	
	@NotNull
	@Column(name="LAST_NAME")
	private String lastName;
	
	@NotNull
	@Column(name="DEPARTMENT_ID")
	private Integer departmentId;
	
	@Column(name="MANAGER_ID")
	private Integer managerId;
	
	@Column(name="PHONE_NUMBER")
	private String phoneNumber;
	
	@Column(name="COMMISSION_PCT")
	private Float comissionPct;
	
	@Column(name="SALARY")
	private Float salary;
	
	@Column(name="FIRST_NAME")
	private String firstName;

	
	// define constructor
	
	public EmployeesEntity() {}

	public EmployeesEntity(Integer employeeId, Date hireDate, String jobId, String email, String lastName,
			Integer departmentId, Integer managerId, String phoneNumber, Float comissionPct, Float salary,
			String firstName) {
		super();
		this.employeeId = employeeId;
		this.hireDate = hireDate;
		this.jobId = jobId;
		this.email = email;
		this.lastName = lastName;
		this.departmentId = departmentId;
		this.managerId = managerId;
		this.phoneNumber = phoneNumber;
		this.comissionPct = comissionPct;
		this.salary = salary;
		this.firstName = firstName;
	}

	
	// define getters and setters
	
	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public Date getHireDate() {
		return hireDate;
	}

	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	public Integer getManagerId() {
		return managerId;
	}

	public void setManagerId(Integer managerId) {
		this.managerId = managerId;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Float getComissionPct() {
		return comissionPct;
	}

	public void setComissionPct(Float comissionPct) {
		this.comissionPct = comissionPct;
	}

	public Float getSalary() {
		return salary;
	}

	public void setSalary(Float salary) {
		this.salary = salary;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	
	// define toString
	
	@Override
	public String toString() {
		return "EmployeesEntity [employeeId=" + employeeId + ", hireDate=" + hireDate + ", jobId=" + jobId + ", email="
				+ email + ", lastName=" + lastName + ", departmentId=" + departmentId + ", managerId=" + managerId
				+ ", phoneNumber=" + phoneNumber + ", comissionPct=" + comissionPct + ", salary=" + salary
				+ ", firstName=" + firstName + "]";
	}
	
}
