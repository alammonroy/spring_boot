package com.indra.bbva.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.sun.istack.NotNull;

@Entity
@Table(name="COUNTRIES")
public class CountriesEntity {
	
	// define fields
	
	@Id
	@NotNull
	@Column(name="COUNTRY_ID")
	private String countryId;
	
	@Column(name="COUNTRY_NAME")
	private String countryName;
	
	@Column(name="REGION_ID")
	private Integer regionId;
	
	
	// define constructor
	
	public CountriesEntity() {}

	public CountriesEntity(String countryId, String countryName, Integer regionId) {
		super();
		this.countryId = countryId;
		this.countryName = countryName;
		this.regionId = regionId;
	}
	
	
	// define getters and setters
	
	public String getCountryId() {
		return countryId;
	}

	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public Integer getRegionId() {
		return regionId;
	}

	public void setRegionId(Integer regionId) {
		this.regionId = regionId;
	}
	
	
	// define toString

	@Override
	public String toString() {
		return "CountriesEntity [countryId=" + countryId + ", countryName=" + countryName + ", regionId=" + regionId
				+ "]";
	}
		
}
