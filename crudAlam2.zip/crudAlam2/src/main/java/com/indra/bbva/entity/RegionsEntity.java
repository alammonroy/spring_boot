package com.indra.bbva.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.sun.istack.NotNull;

@Entity
@Table(name="REGIONS")
public class RegionsEntity {
	
	// define fields
	
	@Id
	@NotNull
	@Column(name="REGION_ID")
	private Integer regionId;
	
	@Column(name="REGION_NAME")
	private String regionName;
	

	// define constructor
	
	public RegionsEntity() {}

	public RegionsEntity(Integer regionId, String regionName) {
		super();
		this.regionId = regionId;
		this.regionName = regionName;
	}


	// define setters and getters
	
	public Integer getRegionId() {
		return regionId;
	}


	public void setRegionId(Integer regionId) {
		this.regionId = regionId;
	}


	public String getRegionName() {
		return regionName;
	}


	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}


	// define toString
	
	@Override
	public String toString() {
		return "RegionsEntity [regionId=" + regionId + ", regionName=" + regionName + "]";
	}

}
