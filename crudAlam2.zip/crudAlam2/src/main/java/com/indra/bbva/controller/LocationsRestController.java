package com.indra.bbva.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.indra.bbva.entity.LocationsEntity;
import com.indra.bbva.service.ILocationsService;

@RestController
@RequestMapping("/hr")
public class LocationsRestController {
	
	// inject ILocationsService
	private ILocationsService locationsService;
	
	@Autowired
	public LocationsRestController(ILocationsService theLocationsService) {
		locationsService = theLocationsService;
	}
	
	// expose "/locations" and return list of locations
	@GetMapping("/locations")
	public List<LocationsEntity> getLocations() {
		return locationsService.findAll();
	}
	
	// add mapping for GET /locations/{locationId}
	@GetMapping("/locations/{locationId}")
	public LocationsEntity getLocation(@PathVariable int locationId) {
		return locationsService.findById(locationId);

	}
	
	// add mapping for POST /locations - add new employee
	@PostMapping("/locations")
	public LocationsEntity addLocation(@RequestBody LocationsEntity theLocation) {
		locationsService.save(theLocation);
		return theLocation;
	}
	
	// add mapping for PUT /locations - update existing location
	@PutMapping("/locations")
	public LocationsEntity updateLocation (@RequestBody LocationsEntity theLocation) {
		locationsService.updateById(theLocation);
		return theLocation;
	}
	
	@DeleteMapping("/locations/{locationId}")
	public String deleteLocation(@PathVariable int locationId) {
		locationsService.deleteById(locationId);
		return "Deleted location id - " + locationId;
	}
}
