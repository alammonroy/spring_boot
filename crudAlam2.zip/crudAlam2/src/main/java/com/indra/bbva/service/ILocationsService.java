package com.indra.bbva.service;

import java.util.List;

import com.indra.bbva.entity.LocationsEntity;

public interface ILocationsService {
	
	public abstract List<LocationsEntity> findAll();
	
	public abstract LocationsEntity findById(int theId);
	
	public abstract void save(LocationsEntity theLocation);
	
	public abstract void updateById(LocationsEntity theLocation);
	
	public abstract void deleteById(int theId);

}
