package com.indra.bbva.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.bbva.entity.CountriesEntity;
import com.indra.bbva.repository.ICountriesRepository;

@Service
public class CountriesServiceImp implements ICountriesService {

	// inject ICountriesRepository
	private ICountriesRepository countriesRepository;
	
	@Autowired
	public CountriesServiceImp(ICountriesRepository theCountriesRepository) {
		countriesRepository = theCountriesRepository;
	}
	
	@Override
	public List<CountriesEntity> findAll() {
		return countriesRepository.findAll();
	}

	@Override
	public CountriesEntity findById(String theId) {
		Optional<CountriesEntity> tempCountry = countriesRepository.findById(theId);
		CountriesEntity theCountry = null;
		if (tempCountry.isPresent())
			theCountry = tempCountry.get();
		else
			// we didn't find the country
			throw new RuntimeException("Did not find country id - " + theId);
		return theCountry;
	}

	@Override
	public void save(CountriesEntity theCountry) {
		String theId = theCountry.getCountryId();
		Optional<CountriesEntity> tempCountry = countriesRepository.findById(theId);
		if (tempCountry.isPresent())
			// already exists country id
			throw new RuntimeException("Already exists country id - " + theId);
		else
			countriesRepository.save(theCountry);
	}

	@Override
	public void updateById(CountriesEntity theCountry) {
		String theId = theCountry.getCountryId();
		Optional<CountriesEntity> tempCountry = countriesRepository.findById(theId);
		if (tempCountry.isPresent())
			countriesRepository.save(theCountry);
		else
			// we didn't find the country
			throw new RuntimeException("Did not find country id - " + theId);
	}
	
	@Override
	public void deleteById(String theId) {
		Optional<CountriesEntity> tempCountry = countriesRepository.findById(theId);
		if (tempCountry.isPresent())
			countriesRepository.deleteById(theId);
		else
			// we didn't find the country
			throw new RuntimeException("Did not find country id - " + theId);
	}

}
