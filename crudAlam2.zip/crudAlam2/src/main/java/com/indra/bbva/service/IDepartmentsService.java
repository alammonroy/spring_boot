package com.indra.bbva.service;

import java.util.List;

import com.indra.bbva.entity.DepartmentsEntity;

public interface IDepartmentsService {

	public abstract List<DepartmentsEntity> findAll();
	
	public abstract DepartmentsEntity findById(int theId);
	
	public abstract void save(DepartmentsEntity theDepartment);
	
	public abstract void updateById(DepartmentsEntity theDepartment);
	
	public abstract void deleteById(int theId);
	
}
