package com.indra.bbva.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.indra.bbva.entity.JobsEntity;
import com.indra.bbva.service.IJobsService;

@RestController
@RequestMapping("/hr")
public class JobsRestController {
	
	// inject IJobsService
	private IJobsService jobsService;
	
	@Autowired
	public JobsRestController(IJobsService theJobsService) {
		jobsService = theJobsService;
	}
	
	// expose "/jobs" and return list of jobs
	@GetMapping("/jobs")
	public List<JobsEntity> getJobs() {
		return jobsService.findAll();
	}
	
	// add mapping for GET /jobs/{jobId}
	@GetMapping("/jobs/{jobId}")
	public JobsEntity getJob(@PathVariable String jobId) {
		return jobsService.findById(jobId);

	}
	
	// add mapping for POST /jobs - add new job
	@PostMapping("/jobs")
	public JobsEntity addJob(@RequestBody JobsEntity theJob) {
		jobsService.save(theJob);
		return theJob;
	}
	
	// add mapping for PUT /jobs - update existing job
	@PutMapping("/jobs")
	public JobsEntity updateJob(@RequestBody JobsEntity theJob) {
		jobsService.updateById(theJob);
		return theJob;
	}
	
	@DeleteMapping("/jobs/{jobId}")
	public String deleteJob(@PathVariable String jobId) {
		jobsService.deleteById(jobId);
		return "Deleted job id - " + jobId;
	}
	
}
