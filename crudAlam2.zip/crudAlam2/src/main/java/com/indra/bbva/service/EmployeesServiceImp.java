package com.indra.bbva.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.bbva.entity.EmployeesEntity;
import com.indra.bbva.repository.IEmployeesRepository;

@Service
public class EmployeesServiceImp implements IEmployeesService {
	
	// inject IEmployeesRepository
	private IEmployeesRepository employeesRepository;
	
	@Autowired
	public EmployeesServiceImp(IEmployeesRepository theEmployeeRepository) {
		employeesRepository = theEmployeeRepository;
	}
	
	@Override
	public List<EmployeesEntity> findAll() {
		return employeesRepository.findAll();
	}

	@Override
	public EmployeesEntity findById(int theId) {
		Optional<EmployeesEntity> tempEmployee = employeesRepository.findById(theId);
		EmployeesEntity theEmployee = null;
		if (tempEmployee.isPresent())
			theEmployee = tempEmployee.get();
		else
			// we didn't find the employee
			throw new RuntimeException("Did not find employee id - " + theId);
		return theEmployee;
	}

	@Override
	public void save(EmployeesEntity theEmployee) {
		employeesRepository.save(theEmployee);
	}

	@Override
	public void updateById(EmployeesEntity theEmployee) {
		int theId = theEmployee.getEmployeeId();
		Optional<EmployeesEntity> tempEmployee = employeesRepository.findById(theId);
		if (tempEmployee.isPresent())
			employeesRepository.save(theEmployee);
		else
			// we didn't find the employee
			throw new RuntimeException("Did not find employee id - " + theId);
	}
	
	@Override
	public void deleteById(int theId) {
		Optional<EmployeesEntity> tempEmployee = employeesRepository.findById(theId);
		if (tempEmployee.isPresent())
			employeesRepository.deleteById(theId);
		else
			// we didn't find the employee
			throw new RuntimeException("Did not find employee id - " + theId);
	}
}
