package com.indra.bbva.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.indra.bbva.entity.CountriesEntity;
import com.indra.bbva.service.ICountriesService;

@RestController
@RequestMapping("/hr")
public class CountriesRestController {
	
	// inject ICountriesService
	private ICountriesService countriesService;
	
	@Autowired
	public CountriesRestController(ICountriesService theCountriesService) {
		countriesService = theCountriesService;
	}
	
	// expose "/countries" and return list of countries
	@GetMapping("/countries")
	public List<CountriesEntity> getCountries() {
		return countriesService.findAll();
	}
	
	// add mapping for GET /countries/{countryId}
	@GetMapping("/countries/{countryId}")
	public CountriesEntity getCountry(@PathVariable String countryId) {
		return countriesService.findById(countryId);

	}
	
	// add mapping for POST /countries - add new country
	@PostMapping("/countries")
	public CountriesEntity addCountry(@RequestBody CountriesEntity theCountry) {
		countriesService.save(theCountry);
		return theCountry;
	}
	
	// add mapping for PUT /countries - update existing country
	@PutMapping("/countries")
	public CountriesEntity updateCountry(@RequestBody CountriesEntity theCountry) {
		countriesService.updateById(theCountry);
		return theCountry;
	}
	
	@DeleteMapping("/countries/{countryId}")
	public String deleteCountry(@PathVariable String countryId) {
		countriesService.deleteById(countryId);
		return "Deleted country id - " + countryId;
	}
}
