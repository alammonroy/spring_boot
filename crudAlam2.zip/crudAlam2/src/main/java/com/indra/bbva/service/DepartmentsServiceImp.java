package com.indra.bbva.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.bbva.entity.DepartmentsEntity;
import com.indra.bbva.repository.IDepartmentsRepository;

@Service
public class DepartmentsServiceImp implements IDepartmentsService {
	
	// inject IDepartmentRepository
	private IDepartmentsRepository departmentsRepository;
	
	@Autowired
	public DepartmentsServiceImp(IDepartmentsRepository thedepartmentsRepository) {
		departmentsRepository = thedepartmentsRepository;
	}
	
	@Override
	public List<DepartmentsEntity> findAll() {
		return departmentsRepository.findAll();
	}

	@Override
	public DepartmentsEntity findById(int theId) {
		Optional<DepartmentsEntity> tempDepartment = departmentsRepository.findById(theId);
		DepartmentsEntity theDepartment = null;
		if (tempDepartment.isPresent())
			theDepartment = tempDepartment.get();
		else
			// we didn't find the department
			throw new RuntimeException("Did not find department id - " + theId);
		return theDepartment;
	}

	@Override
	public void save(DepartmentsEntity theDepartment) {
		departmentsRepository.save(theDepartment);
	}

	@Override
	public void updateById(DepartmentsEntity theDepartment) {
		int theId = theDepartment.getDepartmentId();
		Optional<DepartmentsEntity> tempDepartment = departmentsRepository.findById(theId);
		if (tempDepartment.isPresent())
			departmentsRepository.save(theDepartment);
		else
			// we didn't find the department
			throw new RuntimeException("Did not find department id - " + theId);
	}
	
	@Override
	public void deleteById(int theId) {
		Optional<DepartmentsEntity> tempDepartment = departmentsRepository.findById(theId);
		if (tempDepartment.isPresent())
			departmentsRepository.deleteById(theId);
		else
			// we didn't find the department
			throw new RuntimeException("Did not find department id - " + theId);
	}
}
