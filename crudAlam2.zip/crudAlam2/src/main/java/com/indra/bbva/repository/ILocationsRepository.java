package com.indra.bbva.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.indra.bbva.entity.LocationsEntity;

@Repository
public interface ILocationsRepository extends JpaRepository<LocationsEntity, Integer>{

}
