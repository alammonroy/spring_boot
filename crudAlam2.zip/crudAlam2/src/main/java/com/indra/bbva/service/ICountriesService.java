package com.indra.bbva.service;

import java.util.List;

import com.indra.bbva.entity.CountriesEntity;

public interface ICountriesService {
	
	public abstract List<CountriesEntity> findAll();
	
	public abstract CountriesEntity findById(String theId);
	
	public abstract void save(CountriesEntity theCountry);
	
	public abstract void updateById(CountriesEntity theCountry);
	
	public abstract void deleteById(String theId);
	
}
