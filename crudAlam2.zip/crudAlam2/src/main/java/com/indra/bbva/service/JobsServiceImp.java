package com.indra.bbva.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.bbva.entity.JobsEntity;
import com.indra.bbva.repository.IJobsRepository;

@Service
public class JobsServiceImp implements IJobsService {

	// inject IJobsRepository
	private IJobsRepository jobsRepository;
	
	@Autowired
	public JobsServiceImp(IJobsRepository theJobsRepository) {
		jobsRepository = theJobsRepository;
	}
	
	@Override
	public List<JobsEntity> findAll() {
		return jobsRepository.findAll();
	}

	@Override
	public JobsEntity findById(String theId) {
		Optional<JobsEntity> tempJob = jobsRepository.findById(theId);
		JobsEntity theJob = null;
		if (tempJob.isPresent())
			theJob = tempJob.get();
		else
			// we didn't find the job
			throw new RuntimeException("Did not find job id - " + theId);
		return theJob;
	}

	@Override
	public void save(JobsEntity theJob) {
		String theId = theJob.getJobId();
		Optional<JobsEntity> tempJob = jobsRepository.findById(theId);
		if (tempJob.isPresent())
			// already exists region id
			throw new RuntimeException("Already exists job id - " + theId);
		else
			jobsRepository.save(theJob);
	}

	@Override
	public void updateById(JobsEntity theJob) {
		String theId = theJob.getJobId();
		Optional<JobsEntity> tempJob = jobsRepository.findById(theId);
		if (tempJob.isPresent())
			jobsRepository.save(theJob);
		else
			// we didn't find the job
			throw new RuntimeException("Did not find job id - " + theId);
	}
	
	@Override
	public void deleteById(String theId) {
		Optional<JobsEntity> tempJob = jobsRepository.findById(theId);
		if (tempJob.isPresent())
			jobsRepository.deleteById(theId);
		else
			// we didn't find the job
			throw new RuntimeException("Did not find job id - " + theId);
	}

}
