package com.indra.bbva.service;

import java.util.Date;
import java.util.List;

import com.indra.bbva.entity.JobHistoryEntity;

public interface IJobHistoryService {

	public abstract List<JobHistoryEntity> findAll();
	
	public abstract JobHistoryEntity findById(int employeeId, Date startId);
	
	public abstract void save(JobHistoryEntity theJobHistory);
	
	public abstract void updateById(JobHistoryEntity theJobHistory);
	
	public abstract void deleteById(int employeeId, Date startId);
	

	public abstract List<JobHistoryEntity> findByEmployeeId(int employeeId);
	
	public abstract List<JobHistoryEntity> findByStartDate(Date startDate);
}