package com.indra.bbva.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.sun.istack.NotNull;

@Entity
@Table(name="JOBS")
public class JobsEntity {

	// define fields
	
	@Id
	@NotNull
	@Column(name="JOB_ID")
	private String jobId;
	
	@NotNull
	@Column(name="JOB_TITLE")
	private String jobTitle;
	
	@Column(name="MIN_SALARY")
	private Integer minSalary;
	
	@Column(name="MAX_SALARY")
	private Integer maxSalary;
	
	
	// define constructor
	
	public JobsEntity() {}


	public JobsEntity(String jobId, String jobTitle, Integer minSalary, Integer maxSalary) {
		super();
		this.jobId = jobId;
		this.jobTitle = jobTitle;
		this.minSalary = minSalary;
		this.maxSalary = maxSalary;
	}


	// define getters and setters
	
	public String getJobId() {
		return jobId;
	}


	public void setJobId(String jobId) {
		this.jobId = jobId;
	}


	public String getJobTitle() {
		return jobTitle;
	}


	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}


	public Integer getMinSalary() {
		return minSalary;
	}


	public void setMinSalary(Integer minSalary) {
		this.minSalary = minSalary;
	}


	public Integer getMaxSalary() {
		return maxSalary;
	}


	public void setMaxSalary(Integer maxSalary) {
		this.maxSalary = maxSalary;
	}

	
	// define toString
	
	@Override
	public String toString() {
		return "JobsEntity [jobId=" + jobId + ", jobTitle=" + jobTitle + ", minSalary=" + minSalary + ", maxSalary="
				+ maxSalary + "]";
	}
	
}
