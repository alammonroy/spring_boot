package com.indra.bbva.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.indra.bbva.entity.RegionsEntity;
import com.indra.bbva.service.IRegionsService;

@RestController
@RequestMapping("/hr")
public class RegionsRestController {
	
	// inject IRegionsService
	private IRegionsService regionsService;
	
	@Autowired
	public RegionsRestController(IRegionsService theRegionsService) {
		regionsService = theRegionsService;
	}
	
	// expose "/regions" and return list of regions
	@GetMapping("/regions")
	public List<RegionsEntity> getRegions() {
		return regionsService.findAll();
	}
	
	// add mapping for GET /regions/{regionId}
	@GetMapping("/regions/{regionId}")
	public RegionsEntity getRegion(@PathVariable int regionId) {
		return regionsService.findById(regionId);

	}
	
	// add mapping for POST /regions - add new region
	@PostMapping("/regions")
	public RegionsEntity addRegion(@RequestBody RegionsEntity theRegion) {
		regionsService.save(theRegion);
		return theRegion;
	}
	
	// add mapping for PUT /regions - update existing region
	@PutMapping("/regions")
	public RegionsEntity updateRegion(@RequestBody RegionsEntity theRegion) {
		regionsService.updateById(theRegion);
		return theRegion;
	}
	
	@DeleteMapping("/regions/{regionId}")
	public String deleteRegion(@PathVariable int regionId) {
		regionsService.deleteById(regionId);
		return "Deleted region id - " + regionId;
	}
}
