package com.indra.bbva.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.sun.istack.NotNull;

@Entity
@Table(name="DEPARTMENTS")
public class DepartmentsEntity {
	
	//define fields
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="DEPARTMENTS_SEQ")
	@SequenceGenerator(name="DEPARTMENTS_SEQ", sequenceName="DEPARTMENTS_SEQ", allocationSize=1)
	@NotNull
	@Column(name="DEPARTMENT_ID")
	private Integer departmentId;
	
	@NotNull
	@Column(name="DEPARTMENT_NAME")
	private String departmentName;
	
	@Column(name="MANAGER_ID")
	private Integer managerId;
	
	@Column(name="LOCATION_ID")
	private Integer locationId;
	

	// define constructor
	
	public DepartmentsEntity() {}
	
	public DepartmentsEntity(Integer departmentId, String departmentName, Integer managerId, Integer locationId) {
		super();
		this.departmentId = departmentId;
		this.departmentName = departmentName;
		this.managerId = managerId;
		this.locationId = locationId;
	}


	// define getters and setters

	public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public Integer getManagerId() {
		return managerId;
	}

	public void setManagerId(Integer managerId) {
		this.managerId = managerId;
	}

	public Integer getLocationId() {
		return locationId;
	}

	public void setLocationId(Integer locationId) {
		this.locationId = locationId;
	}
	
	
	// define toString
	
	@Override
	public String toString() {
		return "DepartmentsEntity [departmentId=" + departmentId + ", departmentName=" + departmentName + ", managerId="
				+ managerId + ", locationId=" + locationId + "]";
	}
	
}
