package com.indra.bbva;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrumApplicationTests {

	@Test
	void contextLoads() {
	}

}
