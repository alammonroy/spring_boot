package com.indra.bbva.services;

import java.util.List;
import com.indra.bbva.model.CountriesEntity;

public interface ICountriesServices {
	public abstract List<CountriesEntity> getCountries();
}
