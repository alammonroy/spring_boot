package com.indra.bbva.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Departments")
public class DepartmentsEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "DEPARTMENT_ID")
	private Date departmentId;
	@Column(name = "DEPARTMENT_NAME")
	private Date departmentName;
	@Column(name = "MANAGER_ID")
	private String managerId;
	@Column(name = "LOCATION_ID")
	private int locationId;

	public DepartmentsEntity() {
	}

	public DepartmentsEntity(Date departmentId, Date departmentName, String managerId, int locationId) {
		super();
		this.departmentId = departmentId;
		this.departmentName = departmentName;
		this.managerId = managerId;
		this.locationId = locationId;
	}

	public Date getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Date departmentId) {
		this.departmentId = departmentId;
	}

	public Date getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(Date departmentName) {
		this.departmentName = departmentName;
	}

	public String getManagerId() {
		return managerId;
	}

	public void setManagerId(String managerId) {
		this.managerId = managerId;
	}

	public int getLocationId() {
		return locationId;
	}

	public void setLocationId(int locationId) {
		this.locationId = locationId;
	}

}
