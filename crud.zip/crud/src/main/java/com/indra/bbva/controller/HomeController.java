package com.indra.bbva.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {

	//@PostMapping("/add") @RequestBody int id
	@GetMapping("/CreateUsuarios")
	public String add() {
		return "Add (create)";
	}

	@GetMapping("/get")
	public String get() {
		return "Get (read)";
	}
	
	//@PutMapping("/edit/{id}")
	@GetMapping("/edit")
	public String edit(@PathVariable int id) {
		return "Edit (update)";
	}

	//@DeleteMapping("/delete/{id}")
	@GetMapping("/delete")
	public String delete(@PathVariable int id) {
		return "Delete (delete)";	
	}
	
}
